import { useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useConversations } from "../hooks/useConversations";
import { useConversationMessages } from "../hooks/useConversationMessages";
import { streamChat } from "../lib/api";
import {
  addMessage,
  createConversation,
  deleteMessage,
  renameConversation,
  updateConversation,
} from "../lib/chat";
import { buildMessagePreview } from "../utils/sanitize";
import { ChatComposer } from "../components/ChatComposer";
import { MessageBubble } from "../components/MessageBubble";
import { Onboarding } from "../components/Onboarding";
import { Sidebar } from "../components/Sidebar";

export function ChatPage({ theme, onToggleTheme }) {
  const { user, logout } = useAuth();
  const { conversations, loading: loadingConversations } = useConversations(user.uid);
  const [activeConversationId, setActiveConversationId] = useState("");
  const [mode, setMode] = useState("explain");
  const [pendingMessage, setPendingMessage] = useState(null);
  const [pageError, setPageError] = useState("");
  const [sending, setSending] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const listRef = useRef(null);

  const { messages, loading: loadingMessages } = useConversationMessages(activeConversationId);

  useEffect(() => {
    if (conversations.length && !activeConversationId) {
      setActiveConversationId(conversations[0].id);
    }
  }, [activeConversationId, conversations]);

  useEffect(() => {
    const element = listRef.current;
    if (!element) return;

    element.scrollTop = element.scrollHeight;
  }, [messages, pendingMessage]);

  const combinedMessages = useMemo(() => {
    if (!pendingMessage) return messages;
    return [...messages, pendingMessage];
  }, [messages, pendingMessage]);

  async function ensureConversation(firstPrompt) {
    if (activeConversationId) {
      return activeConversationId;
    }

    const conversationId = await createConversation(user.uid, firstPrompt.slice(0, 48));
    setActiveConversationId(conversationId);
    return conversationId;
  }

  async function handleSend({ message, attachments }) {
    const question = message.trim();
    if (!question && attachments.length === 0) return;

    setSending(true);
    setPageError("");

    try {
      const conversationId = await ensureConversation(question || "Attachment question");
      const existingConversation = conversations.find((item) => item.id === conversationId);
      const displayContent = buildMessagePreview(question || "Please explain this attachment.", attachments);

      await addMessage(conversationId, {
        role: "user",
        content: displayContent,
      });

      const history = messages.slice(-16).map((item) => ({
        role: item.role,
        content: item.content,
      }));

      setPendingMessage({
        id: "pending-assistant",
        role: "assistant",
        content: "",
      });

      let streamedText = "";

      await streamChat(
        {
          conversationId,
          message: question || "Please analyze the uploaded attachment.",
          history,
          mode,
          attachments,
        },
        {
          onToken(token) {
            streamedText += token;
            setPendingMessage({
              id: "pending-assistant",
              role: "assistant",
              content: streamedText,
            });
          },
          async onDone(finalMessage) {
            const responseText = finalMessage || streamedText || "I'm ready to help you learn.";
            await addMessage(conversationId, {
              role: "assistant",
              content: responseText,
            });
            await updateConversation(conversationId, {
              title:
                existingConversation?.title
                || (question ? question.slice(0, 48) : "Attachment question"),
              lastMessage: responseText.slice(0, 140),
            });
            setPendingMessage(null);
          },
          onError(messageText) {
            throw new Error(messageText);
          },
        },
      );
    } catch (error) {
      setPageError(error.message || "Unable to send your message.");
      setPendingMessage(null);
    } finally {
      setSending(false);
    }
  }

  async function handleCopy(message) {
    await navigator.clipboard.writeText(message.content);
  }

  async function handleDelete(message) {
    if (!activeConversationId || !message.id || message.id === "pending-assistant") {
      return;
    }

    await deleteMessage(activeConversationId, message.id);
  }

  async function handleRegenerate(message) {
    const index = messages.findIndex((entry) => entry.id === message.id);
    if (index < 1) return;

    const sourceMessage = messages[index - 1];
    if (sourceMessage.role !== "user") return;

    await handleDelete(message);
    await handleSend({ message: sourceMessage.content, attachments: [] });
  }

  async function handleRenameConversation() {
    if (!activeConversationId) return;
    const title = window.prompt("Rename this conversation");
    if (!title?.trim()) return;

    setRenaming(true);
    try {
      await renameConversation(activeConversationId, title.trim());
    } finally {
      setRenaming(false);
    }
  }

  return (
    <div className="app-shell">
      <Sidebar
        user={user}
        conversations={conversations}
        activeConversationId={activeConversationId}
        onSelectConversation={setActiveConversationId}
        onNewChat={() => {
          setActiveConversationId("");
          setPendingMessage(null);
        }}
        onToggleTheme={onToggleTheme}
        theme={theme}
        mode={mode}
        onModeChange={setMode}
      />

      <main className="chat-page">
        <header className="chat-header">
          <div>
            <h2>
              {conversations.find((item) => item.id === activeConversationId)?.title || "New chat"}
            </h2>
            <p>
              {mode === "quiz" ? "Quiz Mode" : mode === "summary" ? "Summary Mode" : "Explain Mode"}
            </p>
          </div>
          <div className="header-actions">
            <button className="ghost-chip" type="button" onClick={handleRenameConversation} disabled={renaming}>
              {renaming ? "Saving..." : "Rename"}
            </button>
            <button className="ghost-chip" type="button" onClick={logout}>
              Sign out
            </button>
          </div>
        </header>

        {pageError ? <div className="banner error page-banner">{pageError}</div> : null}

        <section className="chat-stream" ref={listRef}>
          {loadingConversations || loadingMessages ? (
            <div className="muted">Loading your study workspace...</div>
          ) : null}

          {!combinedMessages.length && !loadingMessages ? (
            <Onboarding onSelectPrompt={(prompt) => handleSend({ message: prompt, attachments: [] })} mode={mode} />
          ) : null}

          {combinedMessages.map((message) => (
            <MessageBubble
              key={message.id}
              message={message}
              isPending={message.id === "pending-assistant"}
              onCopy={handleCopy}
              onDelete={handleDelete}
              onRegenerate={handleRegenerate}
            />
          ))}
        </section>

        <ChatComposer onSend={handleSend} disabled={sending} />
      </main>
    </div>
  );
}
