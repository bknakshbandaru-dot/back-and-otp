import { buildMessages } from "../utils/messages.js";
import { sanitizeText } from "../utils/sanitize.js";
import { streamCompletion } from "../services/openaiService.js";

function writeEvent(response, payload) {
  response.write(`data: ${JSON.stringify(payload)}\n\n`);
}

export async function streamChat(request, response, next) {
  try {
    const { message, history, mode, attachments } = request.validatedBody;
    const normalizedMessage = sanitizeText(message);

    response.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    });

    const messages = buildMessages({
      history,
      message: normalizedMessage,
      mode,
      attachments,
    });

    await streamCompletion({
      messages,
      attachments,
      onToken(token) {
        writeEvent(response, { type: "token", value: token });
      },
      onComplete(finalMessage) {
        writeEvent(response, { type: "done", message: finalMessage });
        response.end();
      },
    });
  } catch (error) {
    if (!response.headersSent) {
      return next(error);
    }

    writeEvent(response, {
      type: "error",
      message: error.message || "Unable to generate a response right now.",
    });
    response.end();
  }
}
