import { useMemo } from "react";
import { useAuth } from "./context/AuthContext";
import { ChatPage } from "./pages/ChatPage";
import { LoadingPage } from "./pages/LoadingPage";
import { AuthScreen } from "./components/AuthScreen";
import { VerificationGate } from "./components/VerificationGate";
import { useTheme } from "./hooks/useTheme";

function isEmailPasswordUser(user) {
  return user?.providerData?.some((provider) => provider.providerId === "password");
}

export default function App() {
  const { user, loading } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const requiresVerification = useMemo(
    () => Boolean(user && isEmailPasswordUser(user) && !user.emailVerified),
    [user],
  );

  if (loading) {
    return <LoadingPage />;
  }

  if (!user) {
    return <AuthScreen theme={theme} onToggleTheme={toggleTheme} />;
  }

  if (requiresVerification) {
    return <VerificationGate theme={theme} onToggleTheme={toggleTheme} />;
  }

  return <ChatPage theme={theme} onToggleTheme={toggleTheme} />;
}
