import { z } from "zod";

const attachmentSchema = z.object({
  kind: z.enum(["image", "pdf"]),
  name: z.string().trim().min(1).max(120),
  mimeType: z.string().trim().min(1).max(120),
  dataUrl: z.string().trim().max(8_000_000).optional(),
  extractedText: z.string().trim().max(30_000).optional(),
});

const messageSchema = z.object({
  role: z.enum(["user", "assistant", "system"]),
  content: z.string().trim().min(1).max(8_000),
});

const chatSchema = z.object({
  message: z.string().trim().min(1).max(6_000),
  history: z.array(messageSchema).max(30).default([]),
  mode: z.enum(["explain", "quiz", "summary"]).default("explain"),
  attachments: z.array(attachmentSchema).max(4).default([]),
  conversationId: z.string().trim().min(1).max(200).optional(),
});

export function validateChatRequest(request, response, next) {
  const result = chatSchema.safeParse(request.body);

  if (!result.success) {
    return response.status(400).json({
      error: "Invalid request body.",
      details: result.error.flatten(),
    });
  }

  request.validatedBody = result.data;
  return next();
}
