import { Router } from "express";
import { streamChat } from "../controllers/chatController.js";
import { authenticateRequest } from "../middleware/authenticate.js";
import { chatRateLimiter } from "../middleware/rateLimiter.js";
import { validateChatRequest } from "../middleware/validateRequest.js";

export const chatRouter = Router();

chatRouter.post("/", authenticateRequest, chatRateLimiter, validateChatRequest, streamChat);
