import { useMemo, useRef, useState } from "react";

export function useSpeechToText({ onResult }) {
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef(null);

  const supported = useMemo(
    () => Boolean(window.SpeechRecognition || window.webkitSpeechRecognition),
    [],
  );

  function stop() {
    recognitionRef.current?.stop();
    setListening(false);
  }

  function start() {
    if (!supported) {
      throw new Error("Speech recognition is not supported in this browser.");
    }

    const SpeechRecognitionClass = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognitionClass();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      const transcript = event.results?.[0]?.[0]?.transcript || "";
      if (transcript) {
        onResult?.(transcript);
      }
    };

    recognition.onerror = () => {
      setListening(false);
    };

    recognition.onend = () => {
      setListening(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
    setListening(true);
  }

  return {
    supported,
    listening,
    start,
    stop,
  };
}
