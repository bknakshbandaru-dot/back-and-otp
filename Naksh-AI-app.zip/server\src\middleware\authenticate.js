import { verifyIdToken } from "../services/firebaseAdmin.js";

export async function authenticateRequest(request, response, next) {
  try {
    const authHeader = request.headers.authorization || "";

    if (!authHeader.startsWith("Bearer ")) {
      return response.status(401).json({ error: "Missing authorization token." });
    }

    const token = authHeader.slice("Bearer ".length);
    const decodedToken = await verifyIdToken(token);

    request.user = {
      uid: decodedToken.uid,
      email: decodedToken.email || "",
      emailVerified: Boolean(decodedToken.email_verified),
      name: decodedToken.name || "",
    };

    return next();
  } catch (error) {
    return response.status(401).json({ error: "Invalid or expired session." });
  }
}
