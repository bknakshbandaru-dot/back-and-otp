import React from "react";

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error) {
    console.error("Naksh AI UI error", error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="screen-centered">
          <div className="panel status-panel">
            <h1>Something went wrong</h1>
            <p>
              Naksh AI hit an unexpected problem. Refresh the page to try again.
            </p>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
