import { useEffect, useMemo, useState } from "react";
import { confirmPasswordReset, sendPasswordResetEmail } from "firebase/auth";
import { auth } from "../lib/firebase";
import { useAuth } from "../context/AuthContext";

const PASSWORD_RULES = [
  { label: "8+ characters", test: (value) => value.length >= 8 },
  { label: "Uppercase letter", test: (value) => /[A-Z]/.test(value) },
  { label: "Number", test: (value) => /[0-9]/.test(value) },
  { label: "Special character", test: (value) => /[^a-zA-Z0-9]/.test(value) },
];

function getPasswordScore(password) {
  return PASSWORD_RULES.filter((rule) => rule.test(password)).length;
}

function isValidEmail(email) {
  return /\S+@\S+\.\S+/.test(email);
}

function getFriendlyError(error) {
  const code = error?.code || "";

  if (code.includes("invalid-credential")) return "Invalid email or password.";
  if (code.includes("email-already-in-use")) return "That email is already registered.";
  if (code.includes("weak-password")) return "Choose a stronger password.";
  if (code.includes("too-many-requests")) return "Too many attempts. Please wait and try again.";
  if (code.includes("popup-closed-by-user")) return "The Google sign-in popup was closed.";
  if (code.includes("invalid-action-code")) return "This reset link is invalid or expired.";

  return error?.message || "Something went wrong. Please try again.";
}

function Field({ label, type, value, onChange, error, placeholder }) {
  return (
    <label className="field">
      <span>{label}</span>
      <input
        className={error ? "error-input" : ""}
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
      />
      {error ? <small className="field-error">{error}</small> : null}
    </label>
  );
}

export function AuthScreen({ theme, onToggleTheme }) {
  const { loginWithEmail, loginWithGoogle, registerWithEmail } = useAuth();
  const [tab, setTab] = useState("login");
  const [loading, setLoading] = useState("");
  const [bannerError, setBannerError] = useState("");
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [signupForm, setSignupForm] = useState({ name: "", email: "", password: "" });
  const [forgotEmail, setForgotEmail] = useState("");
  const [resetForm, setResetForm] = useState({ password: "", confirm: "" });
  const [forgotSuccess, setForgotSuccess] = useState("");
  const [resetSuccess, setResetSuccess] = useState(false);
  const [errors, setErrors] = useState({});

  const actionCode = useMemo(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get("oobCode") || "";
  }, []);

  useEffect(() => {
    if (actionCode) {
      setTab("reset");
    }
  }, [actionCode]);

  function clearError(field) {
    setBannerError("");
    setErrors((current) => {
      if (!current[field]) return current;
      const next = { ...current };
      delete next[field];
      return next;
    });
  }

  function validateLogin() {
    const nextErrors = {};
    if (!loginForm.email.trim()) nextErrors.loginEmail = "Email is required.";
    else if (!isValidEmail(loginForm.email.trim())) nextErrors.loginEmail = "Enter a valid email.";
    if (!loginForm.password) nextErrors.loginPassword = "Password is required.";
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  function validateSignup() {
    const nextErrors = {};
    if (!signupForm.name.trim()) nextErrors.signupName = "Name is required.";
    if (!signupForm.email.trim()) nextErrors.signupEmail = "Email is required.";
    else if (!isValidEmail(signupForm.email.trim())) nextErrors.signupEmail = "Enter a valid email.";
    if (getPasswordScore(signupForm.password) < 4) {
      nextErrors.signupPassword = "Password must meet all strength rules.";
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  async function handleLogin(event) {
    event.preventDefault();
    if (!validateLogin()) return;

    setLoading("login");
    setBannerError("");

    try {
      await loginWithEmail(loginForm.email.trim(), loginForm.password);
    } catch (error) {
      setBannerError(getFriendlyError(error));
    } finally {
      setLoading("");
    }
  }

  async function handleSignup(event) {
    event.preventDefault();
    if (!validateSignup()) return;

    setLoading("signup");
    setBannerError("");

    try {
      await registerWithEmail(
        signupForm.name.trim(),
        signupForm.email.trim(),
        signupForm.password,
      );
    } catch (error) {
      setBannerError(getFriendlyError(error));
    } finally {
      setLoading("");
    }
  }

  async function handleForgot(event) {
    event.preventDefault();
    if (!isValidEmail(forgotEmail.trim())) {
      setErrors({ forgotEmail: "Enter a valid email." });
      return;
    }

    setLoading("forgot");
    setBannerError("");

    try {
      await sendPasswordResetEmail(auth, forgotEmail.trim());
      setForgotSuccess(forgotEmail.trim());
    } catch (error) {
      setBannerError(getFriendlyError(error));
    } finally {
      setLoading("");
    }
  }

  async function handleReset(event) {
    event.preventDefault();

    const nextErrors = {};
    if (getPasswordScore(resetForm.password) < 4) {
      nextErrors.resetPassword = "Password must meet all strength rules.";
    }
    if (resetForm.password !== resetForm.confirm) {
      nextErrors.resetConfirm = "Passwords do not match.";
    }
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) return;

    setLoading("reset");
    setBannerError("");

    try {
      await confirmPasswordReset(auth, actionCode, resetForm.password);
      setResetSuccess(true);
      window.history.replaceState({}, "", window.location.pathname);
    } catch (error) {
      setBannerError(getFriendlyError(error));
    } finally {
      setLoading("");
    }
  }

  async function handleGoogle() {
    setLoading("google");
    setBannerError("");

    try {
      await loginWithGoogle();
    } catch (error) {
      setBannerError(getFriendlyError(error));
    } finally {
      setLoading("");
    }
  }

  const passwordScore = getPasswordScore(signupForm.password);
  const passwordLabels = ["", "Weak", "Fair", "Good", "Strong"];

  return (
    <div className="screen-centered auth-screen">
      <div className="floating-theme-toggle">
        <button className="ghost-chip" type="button" onClick={onToggleTheme}>
          {theme === "dark" ? "Light mode" : "Dark mode"}
        </button>
      </div>

      <div className="panel auth-panel">
        <div className="auth-header">
          <div className="brand-badge">N</div>
          <div>
            <h1>Naksh AI</h1>
            <p>AI study partner for students</p>
          </div>
        </div>

        <div className="tab-row">
          {["login", "signup", "forgot", "reset"].map((item) => (
            <button
              key={item}
              type="button"
              className={`tab-chip ${tab === item ? "active" : ""}`}
              onClick={() => {
                setTab(item);
                setBannerError("");
                setErrors({});
              }}
            >
              {item === "forgot" ? "Forgot" : item === "reset" ? "Reset" : item === "signup" ? "Sign up" : "Login"}
            </button>
          ))}
        </div>

        {bannerError ? <div className="banner error">{bannerError}</div> : null}

        {tab === "login" ? (
          <form className="stack-md" onSubmit={handleLogin}>
            <Field
              label="Email"
              type="email"
              value={loginForm.email}
              onChange={(event) => {
                clearError("loginEmail");
                setLoginForm((current) => ({ ...current, email: event.target.value }));
              }}
              error={errors.loginEmail}
              placeholder="you@example.com"
            />
            <Field
              label="Password"
              type="password"
              value={loginForm.password}
              onChange={(event) => {
                clearError("loginPassword");
                setLoginForm((current) => ({ ...current, password: event.target.value }));
              }}
              error={errors.loginPassword}
              placeholder="Enter your password"
            />
            <button className="primary-button" type="submit" disabled={loading === "login"}>
              {loading === "login" ? "Signing in..." : "Sign in"}
            </button>
            <button className="secondary-button" type="button" onClick={handleGoogle} disabled={loading === "google"}>
              {loading === "google" ? "Connecting..." : "Continue with Google"}
            </button>
          </form>
        ) : null}

        {tab === "signup" ? (
          <form className="stack-md" onSubmit={handleSignup}>
            <Field
              label="Full name"
              type="text"
              value={signupForm.name}
              onChange={(event) => {
                clearError("signupName");
                setSignupForm((current) => ({ ...current, name: event.target.value }));
              }}
              error={errors.signupName}
              placeholder="Student name"
            />
            <Field
              label="Email"
              type="email"
              value={signupForm.email}
              onChange={(event) => {
                clearError("signupEmail");
                setSignupForm((current) => ({ ...current, email: event.target.value }));
              }}
              error={errors.signupEmail}
              placeholder="you@example.com"
            />
            <Field
              label="Password"
              type="password"
              value={signupForm.password}
              onChange={(event) => {
                clearError("signupPassword");
                setSignupForm((current) => ({ ...current, password: event.target.value }));
              }}
              error={errors.signupPassword}
              placeholder="Create a strong password"
            />
            <div className="password-meter">
              <div className="meter-row">
                {[1, 2, 3, 4].map((value) => (
                  <span
                    key={value}
                    className={`meter-bar ${value <= passwordScore ? "filled" : ""}`}
                  />
                ))}
                <strong>{passwordLabels[passwordScore]}</strong>
              </div>
              <div className="rule-grid">
                {PASSWORD_RULES.map((rule) => (
                  <span key={rule.label} className={rule.test(signupForm.password) ? "pass" : "muted"}>
                    {rule.label}
                  </span>
                ))}
              </div>
            </div>
            <button className="primary-button" type="submit" disabled={loading === "signup"}>
              {loading === "signup" ? "Creating account..." : "Create account"}
            </button>
          </form>
        ) : null}

        {tab === "forgot" ? (
          forgotSuccess ? (
            <div className="stack-md">
              <div className="banner success">
                Reset link sent to {forgotSuccess}. Check your inbox and spam folder.
              </div>
              <button className="primary-button" type="button" onClick={() => setTab("login")}>
                Back to login
              </button>
            </div>
          ) : (
            <form className="stack-md" onSubmit={handleForgot}>
              <Field
                label="Email"
                type="email"
                value={forgotEmail}
                onChange={(event) => {
                  clearError("forgotEmail");
                  setForgotEmail(event.target.value);
                }}
                error={errors.forgotEmail}
                placeholder="you@example.com"
              />
              <button className="primary-button" type="submit" disabled={loading === "forgot"}>
                {loading === "forgot" ? "Sending..." : "Send reset link"}
              </button>
            </form>
          )
        ) : null}

        {tab === "reset" ? (
          resetSuccess ? (
            <div className="stack-md">
              <div className="banner success">Password updated successfully. You can sign in now.</div>
              <button className="primary-button" type="button" onClick={() => setTab("login")}>
                Go to login
              </button>
            </div>
          ) : (
            <form className="stack-md" onSubmit={handleReset}>
              <Field
                label="New password"
                type="password"
                value={resetForm.password}
                onChange={(event) => {
                  clearError("resetPassword");
                  setResetForm((current) => ({ ...current, password: event.target.value }));
                }}
                error={errors.resetPassword}
                placeholder="Create a strong password"
              />
              <Field
                label="Confirm password"
                type="password"
                value={resetForm.confirm}
                onChange={(event) => {
                  clearError("resetConfirm");
                  setResetForm((current) => ({ ...current, confirm: event.target.value }));
                }}
                error={errors.resetConfirm}
                placeholder="Re-enter your password"
              />
              <button className="primary-button" type="submit" disabled={loading === "reset"}>
                {loading === "reset" ? "Updating..." : "Reset password"}
              </button>
            </form>
          )
        ) : null}
      </div>
    </div>
  );
}
