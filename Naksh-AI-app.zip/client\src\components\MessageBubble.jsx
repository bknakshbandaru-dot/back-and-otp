import { MarkdownMessage } from "./MarkdownMessage";

export function MessageBubble({
  message,
  isPending = false,
  onCopy,
  onRegenerate,
  onDelete,
}) {
  const isAssistant = message.role === "assistant";

  return (
    <article className={`message-row ${message.role}`}>
      {isAssistant ? <div className="message-avatar">AI</div> : null}
      <div className={`message-bubble ${message.role}`}>
        <div className="message-body">
          {isPending && !message.content ? (
            <div className="typing-dots"><span /><span /><span /></div>
          ) : (
            <MarkdownMessage content={message.content} />
          )}
        </div>
        {!isPending ? (
          <div className="message-actions">
            <button className="ghost-chip" type="button" onClick={() => onCopy(message)}>
              Copy
            </button>
            {isAssistant ? (
              <button className="ghost-chip" type="button" onClick={() => onRegenerate(message)}>
                Regenerate
              </button>
            ) : null}
            <button className="ghost-chip danger" type="button" onClick={() => onDelete(message)}>
              Delete
            </button>
          </div>
        ) : null}
      </div>
    </article>
  );
}
