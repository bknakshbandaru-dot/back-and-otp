import cors from "cors";
import express from "express";
import helmet from "helmet";
import { chatRouter } from "./routes/chatRoutes.js";

export function createApp() {
  const app = express();
  const clientUrl = process.env.CLIENT_URL || "http://localhost:5173";

  app.use(
    cors({
      origin: clientUrl,
      credentials: true,
    }),
  );
  app.use(helmet({ crossOriginResourcePolicy: false }));
  app.use(
    express.json({
      limit: "10mb",
    }),
  );

  app.get("/health", (_request, response) => {
    response.json({ ok: true });
  });

  app.use("/api/chat", chatRouter);
  app.use("/chat", chatRouter);

  app.use((error, _request, response, _next) => {
    console.error(error);

    if (response.headersSent) {
      return;
    }

    response.status(error.statusCode || 500).json({
      error: error.message || "Internal server error",
    });
  });

  return app;
}
