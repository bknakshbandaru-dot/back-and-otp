export function LoadingPage() {
  return (
    <div className="screen-centered">
      <div className="panel loading-panel">
        <div className="brand-badge">N</div>
        <h1>Naksh AI</h1>
        <p>Loading your learning workspace...</p>
      </div>
    </div>
  );
}
