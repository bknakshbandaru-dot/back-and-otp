import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
} from "firebase/auth";
import { doc, serverTimestamp, setDoc } from "firebase/firestore";
import { auth, db, googleProvider } from "../lib/firebase";

const AuthContext = createContext(null);

async function upsertUser(user) {
  await setDoc(
    doc(db, "users", user.uid),
    {
      id: user.uid,
      email: user.email,
      displayName: user.displayName || user.email?.split("@")[0] || "Naksh user",
      photoURL: user.photoURL || "",
      emailVerified: Boolean(user.emailVerified),
      createdAt: serverTimestamp(),
      lastLoginAt: serverTimestamp(),
    },
    { merge: true },
  );
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      if (nextUser) {
        await upsertUser(nextUser);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const value = useMemo(
    () => ({
      user,
      loading,
      async loginWithGoogle() {
        const result = await signInWithPopup(auth, googleProvider);
        await upsertUser(result.user);
        return result.user;
      },
      async loginWithEmail(email, password) {
        const result = await signInWithEmailAndPassword(auth, email, password);
        await upsertUser(result.user);
        return result.user;
      },
      async registerWithEmail(name, email, password) {
        const result = await createUserWithEmailAndPassword(auth, email, password);
        if (name) {
          await updateProfile(result.user, { displayName: name });
        }
        await sendEmailVerification(result.user);
        await upsertUser({
          ...result.user,
          displayName: name || result.user.displayName,
        });
        return result.user;
      },
      async resendVerification() {
        if (!auth.currentUser) {
          throw new Error("No signed in user found.");
        }

        await sendEmailVerification(auth.currentUser);
      },
      async refreshUser() {
        if (!auth.currentUser) {
          return null;
        }

        await auth.currentUser.reload();
        setUser(auth.currentUser);
        await upsertUser(auth.currentUser);
        return auth.currentUser;
      },
      logout() {
        return signOut(auth);
      },
    }),
    [loading, user],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) {
    throw new Error("useAuth must be used inside AuthProvider.");
  }

  return value;
}
