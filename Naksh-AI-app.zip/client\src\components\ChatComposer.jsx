import { useMemo, useRef, useState } from "react";
import { useDebouncedValue } from "../hooks/useDebouncedValue";
import { useSpeechToText } from "../hooks/useSpeechToText";
import { normalizeAttachment } from "../utils/uploads";

export function ChatComposer({ onSend, disabled }) {
  const fileInputRef = useRef(null);
  const [draft, setDraft] = useState("");
  const [attachments, setAttachments] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [composerError, setComposerError] = useState("");
  const debouncedDraft = useDebouncedValue(draft, 120);

  const { supported, listening, start, stop } = useSpeechToText({
    onResult(transcript) {
      setDraft((current) => `${current}${current ? " " : ""}${transcript}`);
    },
  });

  const canSend = useMemo(
    () => Boolean(debouncedDraft.trim() || attachments.length) && !disabled && !uploading,
    [attachments.length, debouncedDraft, disabled, uploading],
  );

  async function handleFiles(files) {
    if (!files?.length) return;

    setUploading(true);
    setComposerError("");

    try {
      const nextAttachments = await Promise.all([...files].map((file) => normalizeAttachment(file)));
      setAttachments((current) => [...current, ...nextAttachments].slice(0, 4));
    } catch (error) {
      setComposerError(error.message || "Unable to process that file.");
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  }

  async function handleSubmit(event) {
    event?.preventDefault();
    if (!canSend) return;

    const nextDraft = draft;
    const nextAttachments = attachments;
    setDraft("");
    setAttachments([]);
    setComposerError("");

    await onSend({
      message: nextDraft,
      attachments: nextAttachments,
    });
  }

  return (
    <form className="composer" onSubmit={handleSubmit}>
      {attachments.length ? (
        <div className="attachment-strip">
          {attachments.map((attachment) => (
            <span key={`${attachment.kind}-${attachment.name}`} className="attachment-pill">
              {attachment.name}
            </span>
          ))}
        </div>
      ) : null}

      {composerError ? <div className="banner error">{composerError}</div> : null}

      <textarea
        value={draft}
        onChange={(event) => setDraft(event.target.value)}
        placeholder="Ask Naksh AI anything..."
        rows={3}
        disabled={disabled}
      />

      <div className="composer-actions">
        <div className="composer-tools">
          <input
            ref={fileInputRef}
            className="hidden-input"
            type="file"
            accept="image/*,application/pdf"
            multiple
            onChange={(event) => handleFiles(event.target.files)}
          />
          <button className="ghost-chip" type="button" onClick={() => fileInputRef.current?.click()}>
            {uploading ? "Processing..." : "Upload image/PDF"}
          </button>
          {supported ? (
            <button className="ghost-chip" type="button" onClick={listening ? stop : start}>
              {listening ? "Stop mic" : "Voice input"}
            </button>
          ) : null}
        </div>
        <button className="primary-button compact" type="submit" disabled={!canSend}>
          Send
        </button>
      </div>
    </form>
  );
}
