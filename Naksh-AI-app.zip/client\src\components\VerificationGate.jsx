import { useState } from "react";
import { useAuth } from "../context/AuthContext";

export function VerificationGate({ theme, onToggleTheme }) {
  const { user, logout, resendVerification, refreshUser } = useAuth();
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState("");

  async function handleResend() {
    setLoading("resend");
    setStatus("");

    try {
      await resendVerification();
      setStatus(`Verification email sent to ${user.email}.`);
    } catch (error) {
      setStatus(error.message || "Unable to send verification email.");
    } finally {
      setLoading("");
    }
  }

  async function handleRefresh() {
    setLoading("refresh");
    setStatus("");

    try {
      await refreshUser();
      setStatus("Account status refreshed.");
    } catch (error) {
      setStatus(error.message || "Unable to refresh your account.");
    } finally {
      setLoading("");
    }
  }

  return (
    <div className="screen-centered">
      <div className="floating-theme-toggle">
        <button className="ghost-chip" type="button" onClick={onToggleTheme}>
          {theme === "dark" ? "Light mode" : "Dark mode"}
        </button>
      </div>

      <div className="panel status-panel">
        <div className="brand-badge">N</div>
        <h1>Verify your email</h1>
        <p>
          We sent a verification link to <strong>{user?.email}</strong>. Please verify your
          account before using Naksh AI.
        </p>
        {status ? <div className="banner success">{status}</div> : null}
        <div className="status-actions">
          <button className="primary-button" type="button" onClick={handleResend}>
            {loading === "resend" ? "Sending..." : "Resend email"}
          </button>
          <button className="secondary-button" type="button" onClick={handleRefresh}>
            {loading === "refresh" ? "Checking..." : "I've verified"}
          </button>
          <button className="ghost-chip" type="button" onClick={logout}>
            Sign out
          </button>
        </div>
      </div>
    </div>
  );
}
