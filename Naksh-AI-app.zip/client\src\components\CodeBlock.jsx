import { useState } from "react";

export function CodeBlock({ className, children }) {
  const [copied, setCopied] = useState(false);
  const language = className?.replace("language-", "") || "code";
  const code = String(children).replace(/\n$/, "");

  async function handleCopy() {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="code-block">
      <div className="code-header">
        <span>{language}</span>
        <button className="ghost-chip" type="button" onClick={handleCopy}>
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre>
        <code>{code}</code>
      </pre>
    </div>
  );
}
