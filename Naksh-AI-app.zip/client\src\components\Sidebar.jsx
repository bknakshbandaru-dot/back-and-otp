export function Sidebar({
  user,
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewChat,
  onToggleTheme,
  theme,
  mode,
  onModeChange,
}) {
  return (
    <aside className="sidebar">
      <div className="sidebar-top">
        <div className="brand-row">
          <div className="brand-badge">N</div>
          <div>
            <h1>Naksh AI</h1>
            <p>Study partner</p>
          </div>
        </div>
        <button className="primary-button compact" type="button" onClick={onNewChat}>
          New chat
        </button>
        <div className="sidebar-section">
          <label className="label" htmlFor="study-mode">
            Study mode
          </label>
          <select id="study-mode" value={mode} onChange={(event) => onModeChange(event.target.value)}>
            <option value="explain">Explain Mode</option>
            <option value="quiz">Quiz Mode</option>
            <option value="summary">Summary Mode</option>
          </select>
        </div>
        <div className="sidebar-section">
          <button className="ghost-chip" type="button" onClick={onToggleTheme}>
            {theme === "dark" ? "Light mode" : "Dark mode"}
          </button>
        </div>
      </div>

      <div className="sidebar-section conversation-list">
        <h2>Conversations</h2>
        {conversations.length === 0 ? (
          <p className="muted">Start your first study chat.</p>
        ) : (
          conversations.map((conversation) => (
            <button
              key={conversation.id}
              className={`conversation-item ${
                conversation.id === activeConversationId ? "active" : ""
              }`}
              type="button"
              onClick={() => onSelectConversation(conversation.id)}
            >
              <strong>{conversation.title || "New chat"}</strong>
              <span>{conversation.lastMessage || "No messages yet"}</span>
            </button>
          ))
        )}
      </div>

      <div className="profile-card">
        <div className="avatar-circle">
          {(user?.displayName || user?.email || "N")
            .slice(0, 2)
            .toUpperCase()}
        </div>
        <div>
          <strong>{user?.displayName || "Student"}</strong>
          <span>{user?.email}</span>
        </div>
      </div>
    </aside>
  );
}
