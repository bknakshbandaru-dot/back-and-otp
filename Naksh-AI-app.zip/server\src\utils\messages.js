import { sanitizeMessages, sanitizeText } from "./sanitize.js";

const SYSTEM_PROMPTS = {
  explain:
    "You are Naksh AI, a helpful tutor for students of all ages. Explain answers step-by-step in simple language. Use examples when needed.",
  quiz:
    "You are Naksh AI, a helpful tutor for students of all ages. Turn the topic into a short interactive quiz with hints, then explain the correct answers in simple language.",
  summary:
    "You are Naksh AI, a helpful tutor for students of all ages. Summarize the material clearly, highlight key ideas, and end with 3 quick revision points.",
};

const MAX_HISTORY_MESSAGES = 16;
const MAX_CONTEXT_CHARS = 24_000;

export function buildMessages({ history, message, mode, attachments }) {
  const sanitizedHistory = sanitizeMessages(history);
  const trimmedHistory = sanitizedHistory.slice(-MAX_HISTORY_MESSAGES);
  const truncatedHistory = trimByCharacters(trimmedHistory, MAX_CONTEXT_CHARS);
  const attachmentContext = buildAttachmentContext(attachments);
  const userMessage = sanitizeText(message);
  const fullUserMessage = [attachmentContext, userMessage].filter(Boolean).join("\n\n");

  return [
    {
      role: "system",
      content: SYSTEM_PROMPTS[mode] || SYSTEM_PROMPTS.explain,
    },
    ...truncatedHistory,
    {
      role: "user",
      content: fullUserMessage,
    },
  ];
}

function trimByCharacters(messages, maxChars) {
  const result = [];
  let total = 0;

  for (let index = messages.length - 1; index >= 0; index -= 1) {
    const message = messages[index];
    const nextTotal = total + message.content.length;
    if (nextTotal > maxChars) {
      break;
    }

    result.unshift(message);
    total = nextTotal;
  }

  return result;
}

function buildAttachmentContext(attachments) {
  if (!attachments?.length) {
    return "";
  }

  const parts = attachments.map((attachment, index) => {
    if (attachment.kind === "pdf") {
      return `Attachment ${index + 1} (${attachment.name}) PDF excerpt:\n${sanitizeText(
        attachment.extractedText || "",
      )}`;
    }

    if (attachment.kind === "image") {
      return `Attachment ${index + 1}: image uploaded (${attachment.name}). Analyze it with the student's question.`;
    }

    return "";
  });

  return parts.filter(Boolean).join("\n\n");
}
