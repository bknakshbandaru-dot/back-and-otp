export function sanitizePlainText(value) {
  return String(value || "")
    .replace(/\u0000/g, "")
    .trim();
}

export function buildMessagePreview(message, attachments = []) {
  const suffix = attachments.length
    ? `\n\nAttachments: ${attachments.map((item) => item.name).join(", ")}`
    : "";

  return `${sanitizePlainText(message)}${suffix}`.trim();
}
