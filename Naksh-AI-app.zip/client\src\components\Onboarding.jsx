const PROMPTS = [
  "Explain photosynthesis",
  "Solve 2x + 5 = 15",
  "Quiz me on world capitals",
  "Summarize this chapter for revision",
];

export function Onboarding({ onSelectPrompt, mode }) {
  return (
    <div className="onboarding">
      <div className="brand-badge hero-badge">N</div>
      <h2>Learn with Naksh AI</h2>
      <p>
        Use {mode} mode for student-friendly responses, examples, and guided practice.
      </p>
      <div className="prompt-grid">
        {PROMPTS.map((prompt) => (
          <button
            key={prompt}
            className="prompt-card"
            type="button"
            onClick={() => onSelectPrompt(prompt)}
          >
            {prompt}
          </button>
        ))}
      </div>
    </div>
  );
}
