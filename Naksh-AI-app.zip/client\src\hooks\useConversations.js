import { useEffect, useState } from "react";
import {
  collection,
  onSnapshot,
  orderBy,
  query,
  where,
} from "firebase/firestore";
import { db } from "../lib/firebase";

export function useConversations(uid) {
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!uid) {
      setConversations([]);
      setLoading(false);
      return undefined;
    }

    const conversationsQuery = query(
      collection(db, "conversations"),
      where("userId", "==", uid),
      orderBy("updatedAt", "desc"),
    );

    const unsubscribe = onSnapshot(conversationsQuery, (snapshot) => {
      setConversations(
        snapshot.docs.map((entry) => ({
          id: entry.id,
          ...entry.data(),
        })),
      );
      setLoading(false);
    });

    return unsubscribe;
  }, [uid]);

  return { conversations, loading };
}
