export function sanitizeText(input) {
  return String(input || "")
    .replace(/\u0000/g, "")
    .replace(/[^\S\r\n]{3,}/g, "  ")
    .trim();
}

export function sanitizeMessages(messages) {
  return messages
    .map((message) => ({
      role: message.role,
      content: sanitizeText(message.content),
    }))
    .filter((message) => message.content);
}
