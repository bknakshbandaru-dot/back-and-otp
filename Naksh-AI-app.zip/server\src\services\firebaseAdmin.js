import admin from "firebase-admin";

let app;

function getPrivateKey() {
  return (process.env.FIREBASE_PRIVATE_KEY || "").replace(/\\n/g, "\n");
}

function ensureFirebaseAdmin() {
  if (app) {
    return app;
  }

  app = admin.apps[0]
    || admin.initializeApp({
      credential: admin.credential.cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: getPrivateKey(),
      }),
    });

  return app;
}

export function getAdminAuth() {
  return ensureFirebaseAdmin().auth();
}

export async function verifyIdToken(token) {
  return getAdminAuth().verifyIdToken(token);
}
