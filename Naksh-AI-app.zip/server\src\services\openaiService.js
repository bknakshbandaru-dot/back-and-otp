import OpenAI from "openai";

let client;

function getClient() {
  if (!client) {
    client = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }

  return client;
}

export async function streamCompletion({ messages, attachments, onToken, onComplete }) {
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

  const stream = await getClient().chat.completions.create({
    model,
    stream: true,
    temperature: 0.4,
    messages: messages.map((message) => {
      if (message.role !== "user" || !attachments?.length) {
        return message;
      }

      const content = [{ type: "text", text: message.content }];

      for (const attachment of attachments) {
        if (attachment.kind === "image" && attachment.dataUrl) {
          content.push({
            type: "image_url",
            image_url: {
              url: attachment.dataUrl,
            },
          });
        }
      }

      return {
        role: message.role,
        content,
      };
    }),
  });

  let finalText = "";

  for await (const chunk of stream) {
    const token = chunk.choices?.[0]?.delta?.content || "";
    if (!token) {
      continue;
    }

    finalText += token;
    onToken(token);
  }

  onComplete(finalText);
}
